package com.dws.challenge.repository;

import com.dws.challenge.domain.Account;
import com.dws.challenge.exception.DuplicateAccountIdException;

public interface AccountsRepository {

	AccountEntity saveAccount(AccountEntity accountEntity);

    AccountEntity getAccountById(Long id);

    AccountEntity getAccountByEmail(String emailAddress);

    List<AccountEntity> getAllAccounts();

    void deleteAccount(Long id);

    boolean doesAccountExistById(Long id);

    void updateAccountBalancesAndTransactionLog(AccountEntity updatedSenderAccountBalance,
                                           AccountEntity updatedRecieverAccountBalance,
                                           AccountTransactionEntity accountTransactionEntity);

    void updateUserAccountBalance(AccountEntity accountEntity, BigDecimal bigDecimal) throws Exception;
}
