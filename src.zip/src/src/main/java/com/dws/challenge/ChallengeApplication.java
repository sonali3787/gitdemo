package com.dws.challenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChallengeApplication {

	public static final int MAIN_PORT = 8080;
	
	 public static void main(String[] args) {
		SpringApplication.run(ChallengeApplication.class, args);
		setupPortNumber();
       applyCORSFilter();
       initializeRoutes();
   }

   public static void initializeRoutes() {
       Injector injector = Guice.createInjector(new AppModule());
       AccountController accountController = injector.getInstance(AccountController.class);

       post("/accounts", accountController::createAccount);
       get("/accounts", accountController::getAllAccounts);
       get("/accounts/:id", accountController::getAcountById);
      
       post("/accounts/:id/transactions", accountController::createAccountTransaction);
       get("/accounts/:id/transactions", accountController::getAllTransactionsOfAccount);
   }
   public static void setupPortNumber() {
       port(MAIN_PORT);
   }
   public static void startApp() {
       MoneyTransferAPIMainApp.main(null);
       awaitInitialization();
   }
   public static void stopApp() {
       stop();
       awaitStop();
   }

   private static final HashMap<String, String> corsHeaders = new HashMap<>();

   static {
       corsHeaders.put("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS");
       corsHeaders.put("Access-Control-Allow-Origin", "*");
       corsHeaders.put("Access-Control-Allow-Headers", "Content-Type,Authorization,X-Requested-With,Content-Length,Accept,Origin,");
       corsHeaders.put("Access-Control-Allow-Credentials", "true");
   }
  
	}

}
